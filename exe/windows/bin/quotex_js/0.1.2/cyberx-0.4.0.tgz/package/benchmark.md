# Benchmark
CyberX V0.1.0-Beta Build 20220125

### DirectCalc:
##### Environment:
| Module | Specification                          |
| :----: | :------------------------------------- |
| CPU    | Intel Core i7-4790 4C/8T 3.6GHz-4.0GHz |
| RAM    | 16GB DDR3 800MHz Dual (1600MHz)        |
| SYS    | Windows 10 Pro 64-bit 21H1 19043.1466  |

##### C++:
```c++

std::string TestUnit::DirectCalc( int32_t func, int32_t code, std::string& args ) {
	auto json_args = nlohmann::json::parse( args );
	return json_args.dump();
}

```

##### JavaScript:
```javascript

'use strict'

const syscfg = require('syscfg')
const cyberx = require('cyberx')

function Test_Direct_Calc() {
    let kernel = new cyberx.Kernel(new syscfg.SysCfg()) // 全局唯一
    let test_unit = new cyberx.Create('test_unit')
    let calc_args = {'model':'bs', 's':42.0, 'k':40.0, 'r':0.1, 'q':0.0, 'v':0.2, 't':0.5, 'is_call':true}
    let times_count = 100000
    let time_s = new Date()
    for(let i = 0; i < times_count; i++) {
        let result = JSON.parse(test_unit.DirectCalc(0, 0, JSON.stringify(calc_args)))
    }
    let time_e = new Date()
    console.log((time_e - time_s) / 1000)
}

Test_Direct_Calc()

```
执行 100000 次耗时大概 1 秒，每次耗时大概 10 微秒。

##### python:
```python

# -*- coding: utf-8 -*-

import time
import json

import syscfg
import cyberx

def Test_Direct_Calc():
    kernel = cyberx.Kernel(syscfg.SysCfg().ToArgs()) # 全局唯一
    test_unit = cyberx.Create("test_unit")
    calc_args = {"model":"bs", "s":42.0, "k":40.0, "r":0.1, "q":0.0, "v":0.2, "t":0.5, "is_call":True}
    times_count = 50000
    time_s = time.clock()
    for i in range(times_count):
        result = json.loads(test_unit.DirectCalc(0, 0, json.dumps(calc_args)))
    time_e = time.clock()
    print(time_e - time_s)

if __name__ == "__main__":
    Test_Direct_Calc()

```
执行 50000 次耗时大概 1 秒，每次耗时大概 20 微秒。
